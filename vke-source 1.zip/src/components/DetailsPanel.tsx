import { ExpandMore } from "@mui/icons-material";
import { Card, CardContent, Box, Typography, CardActions, Collapse, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from "@mui/material";
import { Coordinate } from "ol/coordinate";
import { useEffect, useState } from "react";
import { DetailsRow } from '@/utils/models';

type DetailsProps = {
    vonatszam: number,
    details: DetailsRow[],
    name:string, 
    type:string,
    date:string,
    plusz:string
};


export const DetailsPanel: React.FC<DetailsProps> = ({ vonatszam, details, name, type, date, plusz }) => {

    const [tableData, setTableData] = useState<DetailsRow[]>();   

    useEffect(() => {
        setTableData(details);
    });

    const convertTimestamp = (time:string) => {
        if(time==null){
            return "";
        }
        else if(time.lastIndexOf(".")>=0){
            return time.substring(0, time.lastIndexOf("."));
        }else {
            return time;
        }
        
    }

    if (tableData) {
        return (
            <Card sx={{backgroundColor: "rgba(255, 255, 255, 0.8)"}}>
                <CardContent >
                    <Typography variant="h6" component="div" gutterBottom sx={{
                        display: 'flex',
                        width: '100%',
                        justifyContent: 'center',
                        alignItems: 'center'
                    }}>
                        {vonatszam} {type} {name}
                    </Typography>
                    <Typography sx={{
                        display: 'flex',
                        width: '100%',
                        justifyContent: 'center',
                        alignItems: 'center'
                    }}>
                        {date}
                    </Typography>
                    <Typography sx={{
                        display: 'flex',
                        width: '100%',
                        fontSize:'12px',
                        justifyContent: 'center',
                        alignItems: 'center'
                    }}>
                        {plusz}
                    </Typography>
                    <TableContainer sx={{height: "calc(100vh - 240px)", overflow: "auto", margin:2}}>
                        <Table>
                            <TableHead>
                                <TableRow>
                                    <TableCell>Km</TableCell>
                                    <TableCell>Állomás</TableCell>
                                    <TableCell>Érkezés</TableCell>
                                    <TableCell>Indulás</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {tableData.map((row, index) => (
                                    <TableRow key={index}>
                                        <TableCell padding="none">{row.Km}</TableCell>
                                        <TableCell padding="none">{row.Állomás}</TableCell>
                                        <TableCell padding="none">
                                            <Typography sx={{
                                                display: 'flex',
                                                width: '100%',
                                                justifyContent: 'center',
                                                alignItems: 'center',
                                                color: '#3287a8',
                                                fontSize:12
                                            }}>
                                                {row.ERK_TERV}
                                            </Typography>
                                            <Typography sx={{
                                                display: 'flex',
                                                width: '100%',
                                                justifyContent: 'center',
                                                alignItems: 'center',
                                                color:'#a84632',
                                                fontSize:12
                                            }}>
                                               {row.ERK_TENY}
                                            </Typography>
                                            <Typography sx={{
                                                display: 'flex',
                                                width: '100%',
                                                justifyContent: 'center',
                                                alignItems: 'center',
                                                color:'#a83292',
                                                fontSize:12
                                            }}>
                                               {convertTimestamp(row.Utolso_erk_pred)}
                                            </Typography>
                                        </TableCell>
                                        <TableCell padding="none"> <Typography sx={{
                                                display: 'flex',
                                                width: '100%',
                                                justifyContent: 'center',
                                                alignItems: 'center',
                                                color: '#3287a8',
                                                fontSize:12
                                            }}>
                                                {row.IND_TERV}
                                            </Typography>
                                            <Typography sx={{
                                                display: 'flex',
                                                width: '100%',
                                                justifyContent: 'center',
                                                alignItems: 'center',
                                                color:'#a84632',
                                                fontSize:12
                                            }}>
                                               {row.IND_TENY}
                                            </Typography>
                                            <Typography sx={{
                                                display: 'flex',
                                                width: '100%',
                                                justifyContent: 'center',
                                                alignItems: 'center',
                                                color:'#a83292',
                                                fontSize:12
                                            }}>
                                               {convertTimestamp(row.Utolso_erk_pred)}
                                            </Typography></TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </CardContent>
            </Card>
        );
    } else {
        return ("");
    }

}