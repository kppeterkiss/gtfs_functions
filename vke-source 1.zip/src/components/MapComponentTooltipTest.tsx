// MapComponent.tsx
import React, { useEffect, useRef, useState } from 'react';
import { Map, Overlay, View } from 'ol';
import TileLayer from 'ol/layer/Tile';
import VectorLayer from 'ol/layer/Vector';
import VectorSource from 'ol/source/Vector';

import { LineString, Point } from 'ol/geom';
import { Feature } from 'ol';
import OSM from 'ol/source/OSM';
import { fromLonLat, ProjectionLike, toLonLat } from 'ol/proj';
import Style from 'ol/style/Style';
import Icon from 'ol/style/Icon';
import 'ol/ol.css';

import { InitialData } from './Main';
import { DetailsPanel } from './DetailsPanel';
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDateFns } from "@mui/x-date-pickers-pro/AdapterDateFns";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import Vector from 'ol/layer/Vector';
import Stroke from 'ol/style/Stroke';
import { hu } from 'date-fns/locale';
import { Alert, Box, Slider, Typography } from '@mui/material';
import { DetailsRow, Train, historyState } from '@/utils/models';
import { createDateString, getColorByDelay } from '@/utils/fn';
import { Circle as CircleStyle, Fill } from 'ol/style';


import Attribution from 'ol/control/Attribution';
import { defaults as defaultControls } from 'ol/control';
import { OGCMapTile } from 'ol/source';

type MapCompProps = {
    config: InitialData,
    historyMode: boolean
};
export const MapComponentTooltipTest: React.FC<MapCompProps> = ({ config, historyMode }) => {

    const now = new Date();
    const mapRef = useRef<Map | null>(null);

    const [selectedTrain, setSelectedTrain] = useState<Train>();
    const [selectedDate, setSelectedDate] = useState<Date | null>(now);
    const [selectedTime, setSelectedTime] = useState<number>(now.getHours() * 60 + now.getMinutes());

    //trains history
    const [trainHistory, setHistory] = useState<historyState[]>();
    const [detailsHistory, setDetailsHistory] = useState<historyState[]>();
    //amit éppen ki kell rajzolni
    const [trains, setTrains] = useState<Train[]>();

    const [info, setInfo] = useState("");
    const [message, setMessage] = useState("");
;
    //details panle cuccai
    const [tableData, setTableData] = useState<DetailsRow[]>();
    const [name, setName] = useState<string>("");
    const [type, setType] = useState<string>("");
    const [date, setDate] = useState<string>("");
    const [plusz, setPlusz] = useState<string>("");
    //detail vége

    const [routeLayer, setRouteLayer] = useState<Vector>(new Vector({
        source: new VectorSource({
            attributions: '© <a href="https://www.elte.hu/">ELTE</a>',
        }),
        style: new Style({
            stroke: new Stroke({
                color: 'blue',
                width: 4,
            }),
        }),
    }));

    const [trainsLayer, setVectorLayer] = useState<Vector>(new Vector({
        source: new VectorSource({
            attributions: '© <a href="https://mav.hu">MÁV Zrt</a>',
        })
    }));

   

   
    const initMap = () => {
        const iconFeature = new Feature({
            geometry: new Point([0, 0]),
            name: "Null Island",
            population: 4000,
            rainfall: 500,
          })
        
          const vectorSource = new VectorSource({
            features: [iconFeature],
          })
        
          const vectorLayer = new VectorLayer({
            source: vectorSource,
          })
        
          const rasterLayer = new TileLayer({
            source: new OGCMapTile({
              url: "https://maps.gnosis.earth/ogcapi/collections/NaturalEarth:raster:HYP_HR_SR_OB_DR/map/tiles/WebMercatorQuad",
              crossOrigin: "",
            }),
          })
        
        
        const container = document.getElementById("popup")
        const overlay = new Overlay({
          element: container!,
          autoPan: {
            animation: {
              duration: 250,
            },
          },
        })
    
        const map = new Map({
          layers: [rasterLayer, vectorLayer],
          target: "markerpopupmap",
          view: new View({
            center: [0, 0],
            zoom: 3,
          }),
          overlays: [overlay],
        })


        const content = document.getElementById("popup-content")  

        map.on("pointermove", function (evt) {
          const coordinate = evt.coordinate
      //    const hdms = toStringHDMS(toLonLat(coordinate))
    
          content!.innerHTML = "<p>You clicked here:</p><code>" + "" + "</code>"
          overlay.setPosition(coordinate)
        })

        mapRef.current = map;
        return () => {
            map.setTarget("");
        };
    };

    useEffect(() => {
        initMap();
    });


    return (
        <div>
          <div style={{ height: '1000px', width: '100%' }} id="markerpopupmap" 
          />
          <div id="popup" className="ol-popup" style={{ backgroundColor: "#fff" }}>
            <div id="popup-content"></div>
          </div>
        </div>
      )
};


