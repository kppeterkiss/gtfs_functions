'use client'
import { useEffect, useState } from "react";

import React, { createContext, useContext } from "react";
import { Login } from "./Login";
import { AppBar, Box, Button, CardMedia, IconButton, Toolbar, Typography } from "@mui/material";
import TrainIcon from '@mui/icons-material/Train';
import LogoutIcon from '@mui/icons-material/Logout';
import HistoryIcon from '@mui/icons-material/History';
import { MapComponent } from "./MapComponent";


export interface InitialData {
  recentTrainsURL: string,
  recentDetailsURL: string,

  historicTrainsURL: string,
  historicDetailsURL: string,

  logoutLimit: number,

  username:string,
  password:string
}


export default function Main() {

  const [username, setUsername] = useState<string>();
  //running változó csak artra kell hogy ne induljon el első betöltéskor kétszer a lekérés
  const [password, setPassword] = useState<string>();
  const [lastLoggedIn, setLastLoggedIn] = useState<number>();
  const [menuVisible, setMenuVisible] = useState<boolean>(false);
  const [historyMode, setHistoryMode] = useState(false); // Betöltési állapot

  const [config, setConfig] = useState<InitialData>();

  useEffect(() => {
    // Dinamikus konfiguráció betöltése
    fetch('/config.json')
      .then((response) => response.json())
      .then((data) => setConfig(data));

    const savedUser = window.localStorage.getItem("username");
    const savedPwd = window.localStorage.getItem("password");
    const lastLogin = window.localStorage.getItem("loginTimestamp");


    if (!username && savedUser && savedUser != username) {
      setUsername(savedUser);
    }
    if (!password && savedPwd && savedPwd != password) {
      setPassword(savedPwd);
    }

    if (!lastLoggedIn && lastLogin && Number.parseInt(lastLogin) != lastLoggedIn) {
      setLastLoggedIn(Number.parseInt(lastLogin));
    }



  }, []);

  async function handleLogin(username: string, password: string) {
    setUsername(username);
    setPassword(password);
    setLastLoggedIn((new Date()).getTime());

    window.localStorage.setItem("username", username);
    window.localStorage.setItem("password", password);
    window.localStorage.setItem("loginTimestamp", (new Date()).getTime().toString());
  }

  function doLogout() {

    window.localStorage.setItem("username", "");
    window.localStorage.setItem("password", "");

    setUsername("");
    setPassword("");
  }

  function changeToHistoryMode() {
    setHistoryMode(!historyMode);
   
  }


  if (!config) {
    return <div>Loading configuration...</div>;
  } else {
    var now = new Date();
    if (!username || !password || !lastLoggedIn || (lastLoggedIn + config.logoutLimit < now.getTime())) {
      return (
        <Login handleLogin={handleLogin} config={config} />
      );
    } else {

      return (
        <>
          <Box sx={{ flexGrow: 1, backgroundColor: '#fbfbfb' }}>
            <AppBar position="static">
              <Toolbar>
                <IconButton
                  size="large"
                  edge="start"
                  color="inherit"
                  aria-label="menu"
                  sx={{ mr: 2 }}
                >
                  <TrainIcon />
                </IconButton>
                <Typography variant="h5" component="div" sx={{ width: '300px' }}>
                Vonat Késés Előrejelző
                </Typography>
                <Box
                  sx={{
                    display: 'flex',
                    flexGrow: 2, 
                    justifyContent: 'center',
                    alignItems: 'center'
                  }}
                >
                  <CardMedia
                    component="img"
                    // height="30"
                    style={{ width: 60, marginRight: 10,  filter: "invert(1)" }}
                    image="/images/MAV.svg"  // A saját képed útvonala
                    alt="MÁVSZK"  // Kép alternatív szövege
                  />
                  <CardMedia
                    component="img"
                    //  height="30"
                    style={{ width: 300, marginRight: 10 }}
                    image="/images/elte-logo-hosszu.svg"  // A saját képed útvonala
                    alt="ELTE"  // Kép alternatív szövege
                  />
                </Box>
                
                <IconButton size="large" edge="end" color="inherit" aria-description="Logout" onClick={doLogout} sx={{paddingRight:0}}><LogoutIcon /></IconButton>
              </Toolbar>
            </AppBar>
          </Box>
          <div style={{
            height: "calc(100vh - 64px)", // Az AppBar alapértelmezett magassága 64px Material-UI szerint
            width: "100%", // A teljes szélességet lefedi
            overflow: "hidden", // Megakadályozza a görgetést
          }}>
            <MapComponent config={config} historyMode={historyMode} />
          </div>
          <div  style={{
                        position: "fixed", // Az elem rögzített pozícióban marad az ablakon belül
                        top: "71px", // Távolság az ablak tetejétől
                        left: "40px", // Távolság az ablak jobb oldalától
                        zIndex: 1000,
                        height: "47px",
                        borderRadius: "4px",
                        borderWidth: "thin",
                        borderColor: "#ccc7c7",
                        borderStyle: "solid",
                        margin:"1px",
                        backgroundColor:"rgba(255, 255, 255, 0.8)",

                  }}>
            <IconButton size="large"
                  color="inherit"
                  onClick={changeToHistoryMode}
                  sx={{
                    padding:1,
                    color: historyMode ? "red" : "inherit", // Ha `historyMode` igaz, piros lesz
                  }}
            ><HistoryIcon />
            </IconButton>
          </div>

        </>
      );
    }


  }

}

