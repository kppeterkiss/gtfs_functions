// MapComponent.tsx
import React, { useEffect, useRef, useState } from 'react';
import { Map, Overlay, View } from 'ol';
import TileLayer from 'ol/layer/Tile';
import VectorLayer from 'ol/layer/Vector';
import VectorSource from 'ol/source/Vector';

import { LineString, Point } from 'ol/geom';
import { Feature } from 'ol';
import OSM from 'ol/source/OSM';
import { fromLonLat, ProjectionLike, toLonLat } from 'ol/proj';
import Style from 'ol/style/Style';
import Icon from 'ol/style/Icon';
import 'ol/ol.css';

import { InitialData } from './Main';
import { DetailsPanel } from './DetailsPanel';
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDateFns } from "@mui/x-date-pickers-pro/AdapterDateFns";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import Vector from 'ol/layer/Vector';
import Stroke from 'ol/style/Stroke';
import { hu } from 'date-fns/locale';
import { Alert, Box, Slider, Typography } from '@mui/material';
import { DetailsRow, Train, historyState } from '@/utils/models';
import { createDateString, getColorByDelay } from '@/utils/fn';
import { Circle as CircleStyle, Fill } from 'ol/style';


import Attribution from 'ol/control/Attribution';
import { defaults as defaultControls } from 'ol/control';
import { FeatureLike } from 'ol/Feature';

type MapCompProps = {
    config: InitialData,
    historyMode: boolean
};
export const MapComponent: React.FC<MapCompProps> = ({ config, historyMode }) => {

    const now = new Date();
    const mapRef = useRef<Map | null>(null);

    const [selectedTrain, setSelectedTrain] = useState<Train>();
    const [loaded, setLoaded] = useState<boolean>(false);

    const [selectedDate, setSelectedDate] = useState<Date | null>(now);
    const [selectedTime, setSelectedTime] = useState<number>(now.getHours() * 60 + now.getMinutes());

    //trains history
    const [trainHistory, setHistory] = useState<historyState[]>();
    const [detailsHistory, setDetailsHistory] = useState<historyState[]>();
    //amit éppen ki kell rajzolni
    const [trains, setTrains] = useState<Train[]>();

    const [info, setInfo] = useState("");
    const [message, setMessage] = useState("");
;
    //details panle cuccai
    const [tableData, setTableData] = useState<DetailsRow[]>();
    const [name, setName] = useState<string>("");
    const [type, setType] = useState<string>("");
    const [date, setDate] = useState<string>("");
    const [plusz, setPlusz] = useState<string>("");
    //detail vége

    const [routeLayer, setRouteLayer] = useState<Vector>(new Vector({
        source: new VectorSource({
            attributions: '© <a href="https://www.elte.hu/">ELTE</a>',
        }),
        style: new Style({
            stroke: new Stroke({
                color: 'blue',
                width: 4,
            }),
        }),
    }));

    const [trainsLayer, setVectorLayer] = useState<Vector>(new Vector({
        source: new VectorSource({
            attributions: '© <a href="https://mav.hu">MÁV Zrt</a>',
        })
    }));

    const processTrains = (trains: Train[], vectorSource: VectorSource) => {
        trains.forEach((t: Train) => {
            const iconFeature = new Feature({
                geometry: new Point(fromLonLat([t.Lon, t.Lat])),
                name: t.Nev,
                vonat: t
            });

            const strokeColor = t==selectedTrain?"graywhite":"#000000";
            const strokeWidth = t==selectedTrain?3:1;

            const circleStyle = new Style({
                image: new CircleStyle({
                    radius: 6,
                    fill: new Fill({
                        color: getColorByDelay(t.Keses),
                    }),
                    stroke: new Stroke({
                        color: strokeColor,
                        width: strokeWidth,
                    }),
                }),
            });

            iconFeature.setStyle(circleStyle);
            vectorSource.addFeature(iconFeature);
        });
    };

    const getReltimeData = () => {
        fetch(config.recentTrainsURL)
            .then((response) => response.json())
            .then((data) => {

                setTrains(data.trains);
                setMessage("");
                setInfo("");

            }).catch((error) => {
                // Hibák logolása és üzenet beállítása
                console.error("Hiba történt a realtime adatok lekérése során:", error);
                setMessage("Hiba történt a realtime adatok lekérése során");
            });
    };

    const getHistoricalData = () => {
        if (!selectedDate) { return; }
        fetch(config.historicTrainsURL + "?date=" + createDateString(selectedDate))
            .then((response) => response.json())
            .then((data) => {
                setHistory(data.states);
                setInfo(data.Info);
                setMessage("");
            }).catch((error) => {
                // Hibák logolása és üzenet beállítása
                console.error("Hiba történt a hisztorikus adatok lekérése során:", error);
                setMessage("Hiba történt a hisztorikus adatok lekérése során");
            });
    };

    const getMapData = () => {
        if (historyMode) {
            getHistoricalData();
        } else {
            getReltimeData();
        }
    };

    const drawTrains = () => {
        const vectorSource = new VectorSource({
            attributions: '© <a href="https://mav.hu">MÁV Zrt</a>',
        });
        processTrains(trains!, vectorSource);
        trainsLayer.setSource(vectorSource);
    };
    const drawTrainTrack = (coordinates: number[][], keses: number) => {
        const route = new LineString(coordinates.map(coord => fromLonLat(coord)));
        routeLayer.setStyle(new Style({
            stroke: new Stroke({
                color: getColorByDelay(keses),
                width: 4,
            }),
        }));
        routeLayer.getSource()?.addFeature(new Feature({
            geometry: route
        }));
    };

    const clearMap = () => {
        trainsLayer.getSource()?.clear();
    };

    const clearTrainTrack = () => {
        routeLayer.getSource()?.clear();
    };

    const refreshTrains = () => {
        if(trains){
            clearMap();
            drawTrains();
        }
        
    };

    const initMap = () => {
        const container = document.getElementById("popup")
        const budapestCenter = fromLonLat([18.9743, 46.9141]); // Longitude, Latitude, (csalás mert nem is Budapest, hanem Dunavecse koordinátáit használjuk)
        const overlay = new Overlay({
            element: container!,
            positioning: 'bottom-center',
            stopEvent: false,
            offset: [0, -10],
            autoPan: {
                animation: {
                    duration: 250,
                },
            },
        });

        const osmLayer = new TileLayer({
            preload: Infinity,
            source: new OSM({
                attributions: [
                    '© <a href="https://www.openstreetmap.org/">OpenStreetMap</a>',
                ],
            }),
        });

        const map = new Map({
            target: 'map',
            layers: [osmLayer, routeLayer, trainsLayer],
            view: new View({
                center: budapestCenter,
                zoom: 8,
            }),

            overlays: [overlay]

        });


        map.on('click', (event) => {
            const feature = map.forEachFeatureAtPixel(event.pixel, (feat) => feat);
            if (feature) {
                setSelectedTrain(feature.get('vonat'));
            } else {
                setSelectedTrain(undefined);

            }
        });

      
        const content = document.getElementById("popup-content")  

        map.on("pointermove", function (evt) {
          const coordinate = evt.coordinate
          const feature = map.forEachFeatureAtPixel(evt.pixel, (feat) => feat);
            if (feature) {
                container?.style.setProperty("display", "block");
                     container!.innerHTML =feature.get('name');
                     overlay.setPosition(coordinate)
            }else{
                container?.style.setProperty("display", "none");
            }
      //    const hdms = toStringHDMS(toLonLat(coordinate))
    
         
          
        })

        mapRef.current = map;
        return () => {
            map.setTarget("");
        };
    };

    useEffect(() => {
        if(!loaded){
            setLoaded(true);
            initMap();
        }
       
    });

    useEffect(() => {
        refreshTrains();
        if (selectedTrain) {
           
            getDetailsFromServer();
        } else {
           
            clearTrainTrack();
        }

    }, [selectedTrain]);

    useEffect(() => {
        getMapData();
    }, [historyMode, selectedDate]);


    useEffect(() => {
        setTrainsToTimestamp();
        setDetialsToTimestamp();

    }, [selectedTime, trainHistory]);

    const setTrainsToTimestamp = () => {
        if (trainHistory && selectedDate && selectedTime) {

            const dateString = selectedDate?.getFullYear() + "-" + (selectedDate?.getMonth() + 1) + "-" + (selectedDate?.getDate() <= 9 ? "0" : "") + selectedDate?.getDate();
            const timestring = valueLabelFormat(selectedTime);
            const myString = dateString + " " + timestring;

            for (let i = 0; i < trainHistory.length; i++) {
                if (trainHistory[i].Timestamp.substring(0, 16) <= myString && trainHistory[i].Valid.substring(0, 16) >= myString) {
                    setTrains(trainHistory[i].trains);
                    setMessage("");
                    return;
                }
            };
            setMessage("Nem található adat a kért időpontra");
            setTrains([]);
        }
    };

    const setDetialsToTimestamp = () => {
        if (selectedTrain && selectedDate && selectedTime && detailsHistory) {
            const dateString = selectedDate?.getFullYear() + "-" + (selectedDate?.getMonth() + 1) + "-" + (selectedDate?.getDate() <= 9 ? "0" : "") + selectedDate?.getDate();
            const timestring = valueLabelFormat(selectedTime);
            const myString = dateString + " " + timestring;

            for (let i = 0; i < detailsHistory.length; i++) {
                if (detailsHistory[i].Timestamp.substring(0, 16) <= myString && detailsHistory[i].Valid.substring(0, 16) >= myString) {
                    setDetails(detailsHistory[i])
                    setMessage("");
                    return;
                }
            };

            setTableData([]);

        }

    };

    useEffect(() => {
        setDetialsToTimestamp();
    }, [detailsHistory])


    useEffect(() => {
        if (trains) {
            drawTrains();
        } else {
            clearMap();
        }
    }, [trains]);



    const setDetails = (data: historyState) => {
        if (data.trains && (data.trains[0])) {
            setName(data.trains[0].Nev);
            setDate(data.trains[0].Nap);
            drawTrainTrack(data.trains[0].geom.coordinates, data.trains[0].Keses);

            if (data.trains[0].Table) {
                setTableData(data.trains[0].Table);
                setType(data.trains[0].TiPUS);
                setPlusz(data.trains[0].PLUSZ);

            }
        }
    };



    const getDetailsFromServer = () => {
        if (!selectedDate) { return; }
        const url = historyMode ? config.historicDetailsURL + "?date=" + createDateString(selectedDate) + "&" : config.recentDetailsURL + "?";
        fetch(url + "Vonatszam=" + selectedTrain?.Vonatszam)
            .then((response) => response.json())
            .then((data) => {
                //historikus adatokat kaptunk
                if (data.states) {
                    setDetailsHistory(data.states);
                } else {
                    setDetails(data);
                }

            });
    }

    const valueLabelFormat = (value: number) => {
        const hour = Math.trunc(value / (60));
        const minute = value - (hour * 60);
        return `${hour <= 9 ? "0" : ""}${hour}:${minute <= 9 ? "0" : ""}${minute}`;
    };


    const handleChangeSlider = (event: Event, value: number | number[], activeThumb: number): void => {
        if (typeof value == 'number') {
            setSelectedTime(value);
        }

    }


    return (
        <>
            <div>
                <div style={{ height: '1000px', width: '100%' }} id="map" />
                <div id="popup" className="ol-popup" style={{ position:"fixed", zIndex:2000, backgroundColor: "#fff", borderRadius:4, paddingTop:"1px", paddingBottom:"1px", paddingLeft:"3px", paddingRight:"2px"}}>
                   
                </div>
            </div>
            {selectedTrain && tableData ?
                <div
                    style={{
                        position: "fixed", // Az elem rögzített pozícióban marad az ablakon belül
                        top: "70px", // Távolság az ablak tetejétől
                        right: "7px", // Távolság az ablak jobb oldalától
                        zIndex: 1000 // Magasabb rétegbe helyezi az elemet
                    }}
                >
                    <DetailsPanel vonatszam={selectedTrain?.Vonatszam} details={tableData} name={name} type={type} date={date} plusz={plusz} />
                </div>
                : ""
            }
            {historyMode ?
                <div
                    style={{
                        position: "fixed", // Az elem rögzített pozícióban marad az ablakon belül
                        top: "72px", // Távolság az ablak tetejétől
                        left: "90px", // Távolság az ablak jobb oldalától
                        zIndex: 1000, // Magasabb rétegbe helyezi az elemet
                        backgroundColor: "rgba(255, 255, 255, 0.8)",
                        borderRadius: "4px",
                        borderWidth: "thin",
                        borderColor: "#ccc7c7",
                        borderStyle: "solid",
                    }}
                >
                    <Box sx={{ width: 250, padding: 1 }}>
                        <LocalizationProvider dateAdapter={AdapterDateFns} adapterLocale={hu}>
                            <DatePicker
                                label="Dátum"
                                value={selectedDate}
                                sx={{ padding: 0 }}
                                onChange={(newValue) => {
                                    setSelectedDate(newValue);
                                }}

                            />
                        </LocalizationProvider>

                        <Typography id="non-linear-slider" sx={{ fontSize: 12 }} gutterBottom>
                            Időpont: {valueLabelFormat((selectedTime!))}
                        </Typography>
                        <Slider
                            value={selectedTime}
                            min={0}
                            step={10}
                            max={1440}
                            //scale={calculateValue}
                            getAriaValueText={valueLabelFormat}
                            valueLabelFormat={valueLabelFormat}
                            onChange={handleChangeSlider}
                            valueLabelDisplay="auto"
                            aria-labelledby="non-linear-slider"
                        />
                    </Box>
                </div>
                : ""}
            {message ?
                <div
                    style={{
                        position: "fixed", // Az elem rögzített pozícióban marad az ablakon belül
                        top: "100px", // Távolság az ablak tetejétől
                        left: "50%", // Távolság az ablak jobb oldalától
                        zIndex: 1000, // Magasabb rétegbe helyezi az elemet
                        backgroundColor: "rgba(255, 255, 255, 0.8)",

                    }}
                >
                    <Alert severity="error">{message}</Alert>
                </div>
                :
                ""}
            {info ?
                <div
                    style={{
                        position: "fixed", // Az elem rögzített pozícióban marad az ablakon belül
                        top: "72px", // Távolság az ablak tetejétől
                        left: "350px", // Távolság az ablak jobb oldalától
                        zIndex: 1000, // Magasabb rétegbe helyezi az elemet
                        backgroundColor: "rgba(255, 255, 255, 0.8)",
                        borderRadius: "4px",
                        borderWidth: "thin",
                        borderColor: "#ccc7c7",
                        borderStyle: "solid",
                    }}
                >
                    <Box sx={{ width: 250, height: 112, margin: 1, borderColor: "#ccc7c7", borderStyle: "solid", borderWidth: "thin", borderRadius: "4px", }}>
                        <Typography id="info-text" sx={{ color: "rgba(0, 0, 0, 0.6)", fontSize: 12, backgroundColor: "rgba(255, 255, 255, 0.8)", position: "relative", top: "-8px", left: "8px", textAlign: "center", width: "70px" }} gutterBottom>
                            Információ
                        </Typography>
                        <Typography id="info" sx={{ fontSize: 12, paddingLeft: 1, paddingRight: 1, paddingTop: 0 }} gutterBottom>
                            {info}
                        </Typography>
                    </Box>

                </div>
                :
                ""}
            
        </>
    );
};


