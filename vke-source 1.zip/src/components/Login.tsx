import { useState } from "react";
import { styled } from '@mui/material/styles';
import MuiCard from '@mui/material/Card';
import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import Box from "@mui/material/Box";
import FormControl from "@mui/material/FormControl";
import FormLabel from "@mui/material/FormLabel";
import Button from "@mui/material/Button";
import React from "react";
import { CardMedia, IconButton } from "@mui/material";
import TrainIcon from '@mui/icons-material/Train';
import { InitialData } from "./Main";



const Card = styled(MuiCard)(({ theme }) => ({
    display: 'flex',
    flexDirection: 'column',
    alignSelf: 'center',
    width: '100%',
    padding: theme.spacing(2),
    gap: theme.spacing(1),
    margin: 'auto',
     maxWidth: '350px',
    [theme.breakpoints.up('sm')]: {
      maxWidth: '350px',
    },
    boxShadow:
      'hsla(220, 30%, 5%, 0.05) 0px 5px 5px 0px, hsla(220, 25%, 10%, 0.05) 0px 15px 35px -5px',
    ...theme.applyStyles('dark', {
      boxShadow:
        'hsla(220, 30%, 5%, 0.5) 0px 5px 5px 0px, hsla(220, 25%, 10%, 0.08) 0px 15px 35px -5px',
    }),
  }));

  const SignInContainer = styled(Stack)(({ theme }) => ({
   // height: 'calc((1 - var(--template-frame-height, 0)) * 100dvh)',
    minHeight: '600px',
    padding: theme.spacing(1),
    [theme.breakpoints.up('sm')]: {
      padding: theme.spacing(1),
    },
    '&::before': {
      content: '""',
      display: 'block',
      position: 'absolute',
      zIndex: -1,
      inset: 0,
      backgroundImage:
        'radial-gradient(ellipse at 50% 50%, hsl(181.5,100%,32%), hsl(181.5,30%,32%))',
      backgroundRepeat: 'no-repeat',
      ...theme.applyStyles('dark', {
        backgroundImage:
          'radial-gradient(at 50% 50%, hsla(210, 100%, 16%, 0.5), hsl(220, 30%, 5%))',
      }),
    },
  }));

type LoginProps = {
    handleLogin: (username: string, password: string) => Promise<void>;
    config:InitialData
  };
  export const Login: React.FC<LoginProps> = ({ handleLogin, config }) => {
    
    const [usernameError, setUsernameError] = React.useState(false);
    const [passwordError, setPasswordError] = React.useState(false);

    const [usernameErrorMessage, setUsernameErrorMessage] = React.useState('');
    const [passwordErrorMessage, setPasswordErrorMessage] = React.useState('');


    const handleSubmit = async (e: any) => {
        e.preventDefault();

        const formData = new FormData(e.currentTarget);
   
        // will call authProvider.login({ username, password })
        if(formData.get('username')!.toString()==config.username &&  formData.get('password')!.toString()==config.password){//sikeres a bejelentkezés
            handleLogin(formData.get('username')!.toString(), formData.get('password')!.toString());
        }else{
          setUsernameError(true);
          setPasswordError(true);
        }
    };

    //nincs igazi validáció, csak eltüntetjük az error jelzést (ha volt), elküldjülk a szervernek, ha nem jó a user/password, kirakjuk az error-t
    const validateInputs = () => {
      
      const username = document.getElementById('username') as HTMLInputElement;
      const password = document.getElementById('password') as HTMLInputElement;
  
      let isValid = true;
  
      if (!username.value || username.value.length == 0) {
        setUsernameError(true);
        setUsernameErrorMessage('Felhasználónév nem lehet üres');
        isValid = false;
      } else {
        setUsernameError(false);
        setUsernameErrorMessage('');
      }
  
      if (!password.value || password.value.length == 0) {
        setPasswordError(true);
        setPasswordErrorMessage('Jelszó nem lehet üres');
        isValid = false;
      } else {
        setPasswordError(false);
        setPasswordErrorMessage('');
      }
      
      return true;
    }

    
    return ( 
        
        <SignInContainer direction="column" justifyContent="space-between">
         
          <Card variant="outlined" sx={{backgroundColor: "#FFFFFF"}}>
          <Box
                  sx={{
                    display: 'flex',
                    flexGrow: 2, 
                    justifyContent: 'center',
                    alignItems: 'center',
                    backgroundColor: "#009fa3",
                    borderRadius:1
                  }}
                >
                  <CardMedia
                    component="img"
                    // height="30"
                    style={{ width: 90, marginRight: 10,  filter: "invert(1)" }}
                    image="/images/MAV.svg"  // A saját képed útvonala
                    alt="MÁVSZK"  // Kép alternatív szövege
                  />
                  <CardMedia
                    component="img"
                    //  height="30"
                    style={{ width: 80, marginRight: 10, color:"black" }}
                    image="/images/elte-logo-kor.svg"  // A saját képed útvonala
                    alt="ELTE IK"  // Kép alternatív szövege
                  />
                  
                  
                </Box>
            <Typography
              component="div"
              variant="h5"
              sx={{ width: '100%', color:"#555555" }}
            >
              Vonat késés előrejelző
            </Typography>
            <Box
              component="form"
              onSubmit={handleSubmit}
              noValidate
              sx={{
                display: 'flex',
                flexDirection: 'column',
                width: '100%',
                gap: 2,
              }}
            >
              <FormControl>
                <FormLabel htmlFor="username">Felhasználónév</FormLabel>
                <TextField
                  error={usernameError}
                  id="username"
                  type="username"
                  name="username"
                  placeholder="felhasználónév"
                  autoComplete="username"
                  autoFocus
                  required
                  fullWidth
                  variant="outlined"
                  color={usernameError ? 'error' : 'primary'}
                />
              </FormControl>
              <FormControl>
                <FormLabel htmlFor="password">Jelszó</FormLabel>
                <TextField
                  error={passwordError}
                  name="password"
                  placeholder="••••••"
                  type="password"
                  id="password"
                  autoComplete="current-password"
                  autoFocus
                  required
                  fullWidth
                  variant="outlined"
                  color={passwordError ? 'error' : 'primary'}
                />
              </FormControl>
             
              
              <Button
                type="submit"
                fullWidth
                variant="contained"
                onClick={validateInputs}
              >
                Bejelentkezés
              </Button>
              
            </Box>
           
          </Card>
        </SignInContainer>

    );
}