export interface historyState {
  Timestamp: string,
  Info: string,
  Valid: string,
  trains: Train[],

}
export interface DetailsRow {
  "Km": number,
  "Állomás": string,
  "ERK_TERV": string,
  "ERK_TENY": string,
  "IND_TERV": string,
  "IND_TENY": string,
  "Utolso_erk_pred": string,
  "Utolso_ind_pred": string
}

export interface Train {
  "Vonatszam": number,
  "Lat": number,
  "Lon": number,
  "Nev": string,
  "Nap": string,
  Keses: number,
  Table: DetailsRow[],
  TiPUS: string,
  PLUSZ: string,
  geom: { type: string, coordinates: [] }
}