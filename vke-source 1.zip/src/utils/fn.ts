export const createDateString = (d:Date) => {
    const day = (d.getUTCDate())<10?"0"+(d.getUTCDate()):(d.getUTCDate());
    const month = (d.getUTCMonth())<9?"0"+(d.getUTCMonth()+1):(d.getUTCMonth()+1);
    return d.getFullYear() + "-" + month +"-"+day;
}

export function getColorByDelay(keses: number): string {
    if(keses<0){//hamarabb jön a vonat!!!
        return "blue"
    }
    if(keses<=5){
        return "green";
    }else if(keses<=15){
        return "yellow";
    }else if(keses<=30){
        return "orange";
    }else{
        return "red";
    }
}